sed -i -e '/^--$/,+1d' PCA.Rmd
