sed -i -e '/^--$/,+1d' CA.Rmd
