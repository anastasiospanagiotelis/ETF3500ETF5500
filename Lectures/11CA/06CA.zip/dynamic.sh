sed -i '/<!--D-->/a --\n' CA.Rmd
