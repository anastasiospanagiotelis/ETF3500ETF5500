sed -i -e '/^--$/,+1d' MDS.Rmd
